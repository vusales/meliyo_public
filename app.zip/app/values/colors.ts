export default {
    error: "red",
};