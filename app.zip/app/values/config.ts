export default {
    MAP_API: '',
    PLACE_AUTO_COMPLETE : "" , 
    APP_VERSION: '',
    URL_PREFIX: '' ,
}