/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */ 

import React,  {useState} from 'react';
import type {PropsWithChildren } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import helper from './helpers/helper';



type SectionProps = PropsWithChildren<{
  title: string;
}>;

const  Section : React.FC<SectionProps> = ({children, title  }) => {

  return (
    <View >
      <Text style={ styles.text}>Hello </Text>
      {children}
    </View>
  );
}

const  App:React.FC = () => {

  return (
    <SafeAreaView>
      <StatusBar/>
      <Section title="smth" > 
      </Section>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  text: {
    fontFamily: helper.fontFamily("Bold") , 
  }
  
});

export default App;
